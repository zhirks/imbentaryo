<?php
    $is_invalid = false;

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $mysqli = require __DIR__ . "/database.php";
        //$password_hash = password_hash($_POST["pass"], PASSWORD_DEFAULT); create password_has value
        
        $sql = sprintf("SELECT * FROM login
                        WHERE username = '%s'",
                        $mysqli->real_escape_string($_POST["user"])
                    );
        
        $result = $mysqli->query($sql);
        $user = $result->fetch_assoc();
        
        if($user){
            if(password_verify($_POST["pass"], $user["password_hash"])){
                session_start();

                session_regenerate_id();

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["loggedIn"] = true;
                
                header("Location: index.php");
                exit;
            }
        }

        $is_invalid = true;
    }  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Easy inventory with imbentaryo™</title>
    <link rel="stylesheet" type="text/css" href="/assets/css/login.css">
</head>
<body>
    <div id="form">
        <h1>Login to imbentaryo™</h1>

        <?php if($is_invalid) : ?>
            <em>Invalid login</em>
        <?php endif; ?>

        <form method="POST">
            <label>Username: </label>
            <input type="text" id="user" name="user" value="<?= htmlspecialchars($_POST["user"] ?? "") ?>">
            </br></br>
            <label>Password: </label>
            <input type="password" id="pass" name="pass"></br></br>
            <input type="submit" id="btn" value="Login" name="submit"/>
        </form>
    </div>
</body>
</html>