<?php
    
    
    /*
    if(isset($_POST['submit'])){
        $username = $_POST['user'];
        $password = $_POST['pass'];

        $sql = "select * from login where username = '$username' and password = '$password'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);

        if($count==1){
            header("Location:dashboard.php");
        }
        else{
            echo '<script>
                    window.location.href = "dashboard.php";
                    alert("Login failed, invalid credentials.")
                </script>';
        }
    }
    */
    $is_invalid = false;

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $mysqli = require __DIR__ . "/connection.php";
        //$password_hash = password_hash($_POST["pass"], PASSWORD_DEFAULT); create password_has value
        
        $sql = sprintf("SELECT * FROM login
                        WHERE username = '%s'",
                        $mysqli->real_escape_string($_POST["user"]));
        
        $result = $mysqli->query($sql);
        $user = $result->fetch_assoc();
        
        if($user){
            if(password_verify($_POST["pass"], $user["password_hash"])){
                die("Login successful");
            }
        }

        $is_invalid = true;
    }    

    
 
?>